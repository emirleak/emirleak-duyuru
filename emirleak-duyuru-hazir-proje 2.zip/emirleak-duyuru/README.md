# EMİRLEAK Duyuru Paneli

Next.js tabanlı mobil uyumlu duyuru paneli.

## Çalıştırma
```bash
npm install
npm run dev
```
Ardından `http://localhost:3000` adresini aç.

## Önemli güvenlik notu
Bu paket bir önizleme/prototiptir. Duyurular `localStorage` içinde tutulur; yalnızca aynı tarayıcıda görünür. Yönetici kodu (`1907`) örnek amaçlıdır ve güvenli değildir. Herkese açık gerçek kullanım için sunucu tarafı kimlik doğrulama ve veritabanı (ör. Supabase RLS) kurulmalıdır. Demo kodunu gerçek şifre olarak kullanmayın.
