 "use client";

import { useEffect, useMemo, useState } from "react";

type Announcement = {
  id: number; title: string; body: string; branch: string; tag: string;
  date: string; pinned: boolean;
};

const starter: Announcement[] = [
  { id: 1, title: "EMİRLEAK duyuru paneline hoş geldin", body: "Resmî duyurular, şube haberleri ve önemli bilgilendirmeler burada paylaşılacak.", branch: "Genel", tag: "Bilgilendirme", date: new Date().toISOString(), pinned: true },
  { id: 2, title: "Şube sistemi aktif", body: "Duyurular şubelere göre filtrelenebilir. Yeni duyuru eklemek için yönetici alanını kullan.", branch: "Genel", tag: "Sistem", date: new Date().toISOString(), pinned: false }
];

export default function Home() {
  const [items, setItems] = useState<Announcement[]>(starter);
  const [branch, setBranch] = useState("Tümü");
  const [search, setSearch] = useState("");
  const [admin, setAdmin] = useState(false);
  const [pin, setPin] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [newBranch, setNewBranch] = useState("Genel");
  const [tag, setTag] = useState("Duyuru");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("emirleak-announcements");
    if (saved) { try { setItems(JSON.parse(saved)); } catch {} }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem("emirleak-announcements", JSON.stringify(items));
  }, [items, ready]);

  const branches = useMemo(() => ["Tümü", ...Array.from(new Set(items.map(x => x.branch)))], [items]);
  const filtered = items.filter(x => (branch === "Tümü" || x.branch === branch) &&
    (x.title + " " + x.body + " " + x.tag).toLocaleLowerCase("tr").includes(search.toLocaleLowerCase("tr")))
    .sort((a,b) => Number(b.pinned)-Number(a.pinned) || b.date.localeCompare(a.date));

  function login() {
    // Demo-only gate. Replace with server-side authentication before public deployment.
    if (pin === "1907") { setAdmin(true); setPin(""); }
    else alert("Kod hatalı.");
  }
  function publish() {
    if (!title.trim() || !body.trim()) return alert("Başlık ve açıklama gerekli.");
    setItems([{ id: Date.now(), title: title.trim(), body: body.trim(), branch: newBranch.trim() || "Genel", tag: tag.trim() || "Duyuru", date: new Date().toISOString(), pinned: false }, ...items]);
    setTitle(""); setBody(""); alert("Duyuru eklendi.");
  }
  return <main className="shell">
    <header className="topbar"><a className="brand" href="#"><span className="mark">E</span><span>EMİRLEAK</span></a><span className="live"><i /> RESMÎ DUYURU</span></header>
    <section className="hero">
      <div className="eyebrow">LEAK MEDIA · DUYURU MERKEZİ</div>
      <h1>Bilgi burada.<br/><em>Gündem burada.</em></h1>
      <p>EMİRLEAK topluluğunun duyurularını tek noktadan takip et.</p>
      <div className="heroLine"><span>GÜNCEL PAYLAŞIMLAR</span><span>{items.length.toString().padStart(2,"0")} DUYURU</span></div>
    </section>
    <section className="toolbar">
      <div className="filters">{branches.map(b => <button key={b} className={branch===b?"chip active":"chip"} onClick={()=>setBranch(b)}>{b}</button>)}</div>
      <input className="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Duyurularda ara..." />
    </section>
    <section className="feed">
      <div className="sectionHead"><div><span className="eyebrow">DUYURU AKIŞI</span><h2>Son gelişmeler</h2></div><span className="count">{filtered.length} sonuç</span></div>
      {filtered.length ? filtered.map(item => <article className="post" key={item.id}>
        <div className="postTop"><span className="tag">{item.tag}</span>{item.pinned && <span className="pinned">SABİTLENDİ</span>}<time>{new Date(item.date).toLocaleDateString("tr-TR")}</time></div>
        <h3>{item.title}</h3><p>{item.body}</p><div className="postFoot"><span>⌁ {item.branch} ŞUBESİ</span><span>EMİRLEAK</span></div>
      </article>) : <div className="empty">Bu filtrede duyuru bulunamadı.</div>}
    </section>
    <footer><div className="brand"><span className="mark small">E</span> EMİRLEAK</div><span>© {new Date().getFullYear()} · Tüm hakları saklıdır.</span><button className="adminLink" onClick={()=>setAdmin(!admin)}>{admin?"Yönetimi kapat":"Yönetici girişi"}</button></footer>
    {admin && <section className="admin">
      <div className="sectionHead"><div><span className="eyebrow">KONTROL MERKEZİ</span><h2>Yönetici paneli</h2></div><button className="close" onClick={()=>setAdmin(false)}>Kapat ×</button></div>
      <p className="warning">ÖNİZLEME MODU: Bu sürümde yönetici kodu ve duyurular tarayıcıda saklanır. Herkese açık gerçek kullanım için güvenli sunucu tarafı giriş ve veritabanı kurulmalıdır.</p>
      {!admin ? <div className="adminForm"><input value={pin} onChange={e=>setPin(e.target.value)} placeholder="Demo yönetici kodu" type="password"/><button className="primary" onClick={login}>Giriş yap</button><small>Demo kodu: 1907</small></div> :
      <div className="adminForm"><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Duyuru başlığı"/><textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="Duyuru açıklaması"/><div className="two"><input value={newBranch} onChange={e=>setNewBranch(e.target.value)} placeholder="Şube"/><input value={tag} onChange={e=>setTag(e.target.value)} placeholder="Etiket"/></div><button className="primary" onClick={publish}>Duyuruyu yayınla</button>
      <div className="manageList"><h3>Paylaşımları yönet</h3>{items.map(x=><div className="manageRow" key={x.id}><span>{x.title}</span><button onClick={()=>setItems(items.map(y=>y.id===x.id?{...y,pinned:!y.pinned}:y))}>{x.pinned?"Sabiti kaldır":"Sabitle"}</button><button className="delete" onClick={()=>setItems(items.filter(y=>y.id!==x.id))}>Sil</button></div>)}</div></div>}
    </section>}
  </main>;
}