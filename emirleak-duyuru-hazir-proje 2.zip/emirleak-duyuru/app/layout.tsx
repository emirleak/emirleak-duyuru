import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EMİRLEAK | Duyuru Paneli",
  description: "EMİRLEAK resmi duyuru paneli"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="tr"><body>{children}</body></html>;
}